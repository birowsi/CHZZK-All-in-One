(() => {
  "use strict";

  function chooseRecorderMime(Recorder) {
    if (typeof Recorder?.isTypeSupported !== "function") return "";
    return [
      "video/webm;codecs=vp9,opus",
      "video/webm;codecs=vp8,opus",
      "video/webm",
    ].find((type) => Recorder.isTypeSupported(type)) || "";
  }

  const blindNoticePattern = /(?:클린봇이\s*부적절한\s*표현을\s*감지|(?:관리자|운영자).*?(?:블라인드|숨김|삭제|차단|가림)|(?:블라인드|숨김|삭제|차단|가림).*?(?:메시지|채팅))/i;
  const isBlindNotice = (text) => blindNoticePattern.test(text || "");

  if (typeof module !== "undefined") module.exports = { chooseRecorderMime, isBlindNotice };
  if (typeof document === "undefined") return;
  if (globalThis.__HANBI_CHZZK_TOOLS__) return;
  globalThis.__HANBI_CHZZK_TOOLS__ = true;

  const api = globalThis.browser ?? globalThis.chrome;
  const defaults = {
    screenshot: true,
    recorder: true,
    autoUnmute: true,
    hideAdPopup: true,
    blindRestore: true,
    trends: true,
    gridBypass: true,
  };
  let features = { ...defaults };
  let recording = null;
  let scheduled = false;
  let trendTimer = null;
  let previewUrl = null;
  const preparedVideos = new WeakSet();
  const originalMessages = new WeakMap();

  const isLive = () => /^\/live\/[^/]+/.test(location.pathname);

  function video() {
    return [...document.querySelectorAll("video")]
      .filter((item) => item.videoWidth && item.readyState >= 2 && item.getBoundingClientRect().width)
      .sort((a, b) => {
        const aRect = a.getBoundingClientRect();
        const bRect = b.getBoundingClientRect();
        return (bRect.width * bRect.height) - (aRect.width * aRect.height);
      })[0] || null;
  }

  function status(message, error = false) {
    let toast = document.getElementById("hanbi-tool-status");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "hanbi-tool-status";
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.toggle("is-error", error);
    clearTimeout(status.timer);
    status.timer = setTimeout(() => toast.remove(), 3500);
  }

  function button(label, text, onClick) {
    const element = document.createElement("button");
    element.type = "button";
    element.className = "pzp-button pzp-setting-button pzp-pc-setting-button pzp-pc__setting-button hanbi-tool-button";
    element.ariaLabel = label;
    element.title = label;
    element.textContent = text;
    element.addEventListener("click", (event) => {
      Promise.resolve(onClick(event)).catch((error) => {
        console.error("[CHZZK All-in-One]", error);
        status(error?.message || "기능 실행에 실패했습니다.", true);
      });
    });
    return element;
  }

  function fileName(extension) {
    const channel = document.querySelector("[class*='channel_name'], [class*='name_text']")?.textContent?.trim() || "chzzk";
    const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "");
    return `${channel}_${stamp}.${extension}`.replace(/[\\/:*?"<>|]/g, "_");
  }

  function download(url, name) {
    const link = document.createElement("a");
    link.href = url;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  function canvasBlob(canvas) {
    return new Promise((resolve, reject) => {
      canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("이미지를 만들 수 없습니다.")), "image/png");
    });
  }

  function showPreview(blob) {
    let overlay = document.getElementById("hanbi-screenshot-preview");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "hanbi-screenshot-preview";
      overlay.innerHTML = '<img alt="스크린샷 미리보기"><div><button type="button" data-save>저장</button><button type="button" data-close>닫기</button></div>';
      document.body.appendChild(overlay);
    }

    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = URL.createObjectURL(blob);
    const image = overlay.querySelector("img");
    image.src = previewUrl;
    overlay.dataset.fileName = fileName("png");
    overlay.querySelector("[data-save]").onclick = () => {
      download(previewUrl, overlay.dataset.fileName);
      overlay.remove();
    };
    overlay.querySelector("[data-close]").onclick = () => overlay.remove();
  }

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("화면 캡처를 불러오지 못했습니다."));
      image.src = src;
    });
  }

  async function captureVisibleVideo(source) {
    const tools = document.getElementById("hanbi-player-tools");
    if (tools) tools.style.visibility = "hidden";
    await new Promise(requestAnimationFrame);
    let dataUrl;
    try {
      dataUrl = await api.runtime.sendMessage({ type: "capture-visible-tab" });
    } finally {
      if (tools) tools.style.visibility = "";
    }
    if (!dataUrl) throw new Error("Firefox 화면 캡처 권한이 없습니다.");

    const image = await loadImage(dataUrl);
    const rect = source.getBoundingClientRect();
    const left = Math.max(0, rect.left);
    const top = Math.max(0, rect.top);
    const right = Math.min(innerWidth, rect.right);
    const bottom = Math.min(innerHeight, rect.bottom);
    if (right <= left || bottom <= top) throw new Error("영상이 화면에 보이지 않습니다.");

    const scaleX = image.naturalWidth / innerWidth;
    const scaleY = image.naturalHeight / innerHeight;
    const canvas = document.createElement("canvas");
    canvas.width = Math.round((right - left) * scaleX);
    canvas.height = Math.round((bottom - top) * scaleY);
    canvas.getContext("2d").drawImage(
      image,
      left * scaleX, top * scaleY, canvas.width, canvas.height,
      0, 0, canvas.width, canvas.height,
    );
    return canvasBlob(canvas);
  }

  async function screenshot() {
    const source = video();
    if (!source) throw new Error("재생 중인 영상을 찾지 못했습니다.");
    const canvas = document.createElement("canvas");
    canvas.width = source.videoWidth;
    canvas.height = source.videoHeight;
    try {
      canvas.getContext("2d").drawImage(source, 0, 0);
      showPreview(await canvasBlob(canvas));
    } catch (_) {
      showPreview(await captureVisibleVideo(source));
    }
  }

  async function togglePip() {
    const source = video();
    if (!source?.requestPictureInPicture) throw new Error("PIP를 지원하지 않는 영상입니다.");
    if (document.pictureInPictureElement) await document.exitPictureInPicture();
    else await source.requestPictureInPicture();
  }

  function resetRecording(session) {
    session.stream.getTracks().forEach((track) => track.stop());
    clearInterval(session.timer);
    session.indicator?.remove();
    session.button.textContent = "REC";
    session.button.classList.remove("is-recording");
    if (recording === session) recording = null;
  }

  async function finishRecording(session) {
    if (session.failed) return;
    if (!session.chunks.length) {
      resetRecording(session);
      status("녹화 데이터가 없습니다.", true);
      return;
    }
    const type = session.recorder.mimeType || "video/webm";
    const blob = new Blob(session.chunks, { type });
    resetRecording(session);
    status("녹화 결과 창을 여는 중…");
    const name = fileName("webm").replace(/\.webm$/, "");
    try {
      await api.runtime.sendMessage({
        type: "recording-complete",
        recording: { blob, fileName: name, mimeType: type, startedAt: session.startedAt, stoppedAt: Date.now() },
      });
      status("녹화 결과 창을 열었습니다.");
    } catch (error) {
      const url = URL.createObjectURL(blob);
      download(url, `${name}.webm`);
      setTimeout(() => URL.revokeObjectURL(url), 30_000);
      status("결과 창을 열지 못해 원본을 대신 저장했습니다.", true);
      console.error("[CHZZK All-in-One recorder]", error);
    }
  }

  function showRecordingIndicator(session) {
    const indicator = document.createElement("div");
    indicator.id = "hanbi-recording-indicator";
    document.body.appendChild(indicator);
    session.indicator = indicator;
    const update = () => {
      const seconds = Math.floor((Date.now() - session.startedAt) / 1000);
      indicator.textContent = `● REC ${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
    };
    update();
    session.timer = setInterval(update, 1000);
  }

  function toggleRecording(buttonElement) {
    if (recording) {
      if (recording.recorder.state !== "inactive") {
        recording.button.textContent = "SAVE";
        recording.recorder.stop();
      }
      return;
    }
    if (typeof MediaRecorder === "undefined") throw new Error("이 Firefox는 녹화를 지원하지 않습니다.");

    const source = video();
    if (!source) throw new Error("재생 중인 영상을 찾지 못했습니다.");
    const capture = source.mozCaptureStream || source.captureStream;
    if (typeof capture !== "function") throw new Error("이 영상은 녹화를 지원하지 않습니다.");
    const stream = capture.call(source);
    if (!stream.getVideoTracks().length) throw new Error("영상 트랙을 가져오지 못했습니다.");

    const mimeType = chooseRecorderMime(MediaRecorder);
    const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    const session = { recorder, stream, button: buttonElement, chunks: [], startedAt: Date.now() };
    recording = session;
    recorder.addEventListener("dataavailable", (event) => event.data.size && session.chunks.push(event.data));
    recorder.addEventListener("stop", () => finishRecording(session).catch((error) => {
      resetRecording(session);
      status(error?.message || "녹화 결과 창을 열지 못했습니다.", true);
    }), { once: true });
    recorder.addEventListener("error", (event) => {
      session.failed = true;
      resetRecording(session);
      status(event.error?.message || "녹화에 실패했습니다.", true);
    }, { once: true });
    recorder.start(1000);
    showRecordingIndicator(session);
    buttonElement.textContent = "STOP";
    buttonElement.classList.add("is-recording");
    status(stream.getAudioTracks().length ? "녹화를 시작했습니다." : "오디오 없이 녹화를 시작했습니다.");
  }

  function ensureTools() {
    const target = document.querySelector(".pzp-pc__bottom-buttons-right");
    const existing = document.getElementById("hanbi-player-tools");
    const hasPip = Boolean(video()?.requestPictureInPicture);
    const signature = `${features.recorder}:${features.screenshot}:${hasPip}`;
    if (!target || (!features.screenshot && !features.recorder && !hasPip)) {
      existing?.remove();
      return;
    }
    if (existing?.parentElement === target && existing.dataset.signature === signature) return;
    existing?.remove();

    const root = document.createElement("span");
    root.id = "hanbi-player-tools";
    root.dataset.signature = signature;
    if (features.recorder) {
      const recordButton = button("녹화 시작/중지", "REC", () => toggleRecording(recordButton));
      root.appendChild(recordButton);
    }
    if (features.screenshot) root.appendChild(button("스크린샷", "SHOT", screenshot));
    if (hasPip) root.appendChild(button("Picture in Picture", "PIP", togglePip));
    target.prepend(root);
  }

  function prepareVideo() {
    const source = video();
    if (!source || preparedVideos.has(source)) return;
    preparedVideos.add(source);
    if (features.autoUnmute && isLive()) {
      source.muted = false;
      source.addEventListener("loadeddata", () => { source.muted = false; }, { once: true });
    }
  }

  function removeAdPopup() {
    if (!features.hideAdPopup) return;
    for (const popup of document.querySelectorAll("div[class^='popup_container'], [role='dialog']")) {
      if (/광고\s*차단\s*프로그램.*사용\s*중/i.test(popup.textContent || "")) popup.remove();
    }
  }

  function rememberAndRestoreBlindMessages() {
    const roots = document.querySelectorAll("[role='log'], [class*='live_chatting'], [class*='chatting'][class*='list']");
    const items = new Set([...roots].flatMap((root) => [...root.querySelectorAll(
      "[data-chat-id], [data-message-id], [role='listitem'], [class*='list_item'], [class*='chat'][class*='item']",
    )]));
    for (const item of items) {
      const text = item.querySelector("[data-message-text], [data-chat-text], [data-content], [class*='message_text'], [class*='message'], [class*='content'], [class*='text']") ?? item;
      const reveal = item.querySelector(".hanbi-restored-message");
      if (!features.blindRestore) {
        text.removeAttribute("data-hanbi-blind-masked");
        reveal?.remove();
        continue;
      }

      const current = (text.innerText || text.textContent || "").trim();
      const identity = item.getAttribute("data-chat-id") || item.getAttribute("data-message-id") || "";
      if (!isBlindNotice(current)) {
        text.removeAttribute("data-hanbi-blind-masked");
        reveal?.remove();
        if (current) originalMessages.set(item, { identity, source: text, text: current });
        continue;
      }

      const hidden = [...item.querySelectorAll("[class*='message'], [class*='content'], [class*='text'], [data-message], [data-content]")]
        .find((candidate) => candidate !== text && getComputedStyle(candidate).display === "none" && !isBlindNotice(candidate.textContent));
      const cached = originalMessages.get(item);
      const original = hidden?.textContent?.trim() || (
        cached?.source === text && cached.identity === identity ? cached.text : ""
      );
      if (!original) continue;

      text.setAttribute("data-hanbi-blind-masked", "1");
      const replacement = reveal || document.createElement("span");
      replacement.className = "hanbi-restored-message";
      replacement.title = "확인 가능한 블라인드 원문";
      replacement.textContent = original;
      if (!replacement.isConnected) text.after(replacement);
    }
  }

  async function updateTrends() {
    if (!features.trends) return;
    let bar = document.getElementById("hanbi-trends");
    const header = document.querySelector("header, [class^='header_container']");
    if (!header) return;
    if (!bar) {
      bar = document.createElement("nav");
      bar.id = "hanbi-trends";
      bar.ariaLabel = "실시간 인기 방송";
      header.after(bar);
    }
    try {
      const response = await fetch("https://api.chzzk.naver.com/service/v1/lives?size=10&sortType=POPULAR", { credentials: "include" });
      if (!response.ok) return;
      const lives = (await response.json())?.content?.data || [];
      bar.replaceChildren(...lives.slice(0, 10).map((live) => {
        const link = document.createElement("a");
        const id = live.channel?.channelId || live.channelId;
        link.href = `/live/${id}`;
        link.textContent = `${live.channel?.channelName || "스트리머"} · ${Number(live.concurrentUserCount || 0).toLocaleString()}`;
        return link;
      }));
    } catch (_) {}
  }

  function applyFeatures() {
    ensureTools();
    prepareVideo();
    removeAdPopup();
    rememberAndRestoreBlindMessages();
    if (!features.trends) document.getElementById("hanbi-trends")?.remove();
  }

  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      applyFeatures();
    });
  }

  api.storage.local.get("features").then(({ features: saved }) => {
    features = { ...defaults, ...saved };
    applyFeatures();
    updateTrends();
    trendTimer = setInterval(updateTrends, 60_000);
  });

  api.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.features) return;
    features = { ...defaults, ...changes.features.newValue };
    applyFeatures();
    updateTrends();
  });

  new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener("pagehide", () => {
    clearInterval(trendTimer);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
  }, { once: true });
})();
