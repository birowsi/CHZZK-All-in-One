const extensionApi = globalThis.browser ?? globalThis.chrome;

async function syncGridBypass() {
  const { os } = await extensionApi.runtime.getPlatformInfo();
  const { features = {} } = await extensionApi.storage.local.get("features");
  const enabled = os === "win" && features.gridBypass !== false;

  await extensionApi.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: enabled ? ["grid_bypass"] : [],
    disableRulesetIds: enabled ? [] : ["grid_bypass"],
  });
}

extensionApi.runtime.onInstalled.addListener(syncGridBypass);
extensionApi.runtime.onStartup.addListener(syncGridBypass);
extensionApi.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.features) syncGridBypass();
});
