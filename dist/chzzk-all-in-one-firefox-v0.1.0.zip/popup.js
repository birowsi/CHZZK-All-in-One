const api = globalThis.browser ?? globalThis.chrome;
const featureDefaults = {
  screenshot: true,
  recorder: true,
  autoUnmute: true,
  hideAdPopup: true,
  blindRestore: true,
  trends: true,
  gridBypass: true,
};
const powerSettings = {
  toggle: ["badge", "updateBadgeToggle", "badgeToggle", true],
  clockToggle: ["clockToggle", "updateClockToggle", "clockToggle", false],
  powerSummaryToggle: ["powerSummary", "updatePowerSummaryToggle", "powerSummaryToggle", false],
  movingGifProfileToggle: ["movingGifProfile", "updateMovingGifProfileToggle", "movingGifProfileToggle", false],
};

async function notifyTab(message) {
  const [tab] = await api.tabs.query({ active: true, currentWindow: true });
  if (tab?.id && tab.url?.includes("chzzk.naver.com")) api.tabs.sendMessage(tab.id, message).catch(() => {});
}

function updateNextPowerTime(logs, lastAcquisitionTime) {
  const now = new Date();
  let next = lastAcquisitionTime ? new Date(new Date(lastAcquisitionTime).getTime() + 3_600_000) : null;
  if (!next || next <= now) {
    const last = logs[0]?.timestamp ? new Date(logs[0].timestamp) : now;
    next = new Date(now);
    next.setMinutes(last.getMinutes(), 0, 0);
    if (next <= now) next.setHours(next.getHours() + 1);
  }
  const minutes = Math.max(0, Math.ceil((next - now) / 60_000));
  document.getElementById("timeDisplay").textContent = minutes ? `${Math.floor(minutes / 60)}시간 ${minutes % 60}분 후`.replace(/^0시간 /, "") : "곧 획득 가능";
}

async function init() {
  const { features: savedFeatures = {} } = await api.storage.local.get("features");
  const features = { ...featureDefaults, ...savedFeatures };
  for (const input of document.querySelectorAll("[data-feature]")) {
    input.checked = features[input.dataset.feature];
    input.addEventListener("change", async () => {
      features[input.dataset.feature] = input.checked;
      await api.storage.local.set({ features });
    });
  }

  const storedPower = await api.storage.sync.get(Object.values(powerSettings).map(([key]) => key));
  for (const [id, [key, action, messageKey, defaultValue]] of Object.entries(powerSettings)) {
    const input = document.getElementById(id);
    input.checked = storedPower[key] ?? defaultValue;
    input.addEventListener("change", async () => {
      await api.storage.sync.set({ [key]: input.checked });
      notifyTab({ action, [messageKey]: input.checked });
    });
  }

  const { powerLogs = [], lastPowerAcquisitionTime } = await api.storage.local.get(["powerLogs", "lastPowerAcquisitionTime"]);
  updateNextPowerTime(powerLogs, lastPowerAcquisitionTime);
  document.getElementById("viewLogs").addEventListener("click", () => api.tabs.create({ url: api.runtime.getURL("log.html") }));
}

init().catch(console.error);
