(() => {
  "use strict";

  if (globalThis.__HANBI_CHZZK_TOOLS__) return;
  globalThis.__HANBI_CHZZK_TOOLS__ = true;

  const api = globalThis.browser ?? globalThis.chrome;
  const defaults = {
    screenshot: true,
    recorder: true,
    autoUnmute: true,
    hideAdPopup: true,
    blindRestore: true,
    trends: true,
    gridBypass: true,
  };
  let features = { ...defaults };
  let recording = null;
  let scheduled = false;
  let trendTimer = null;
  const preparedVideos = new WeakSet();
  const originalMessages = new WeakMap();

  const isLive = () => /^\/live\/[^/]+/.test(location.pathname);
  const video = () => document.querySelector("video.webplayer-internal-video, video");

  function button(label, text, onClick) {
    const element = document.createElement("button");
    element.type = "button";
    element.className = "pzp-button pzp-setting-button pzp-pc-setting-button pzp-pc__setting-button hanbi-tool-button";
    element.ariaLabel = label;
    element.title = label;
    element.textContent = text;
    element.addEventListener("click", onClick);
    return element;
  }

  function fileName(extension) {
    const channel = document.querySelector("[class*='channel_name'], [class*='name_text']")?.textContent?.trim() || "chzzk";
    const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "");
    return `${channel}_${stamp}.${extension}`.replace(/[\\/:*?"<>|]/g, "_");
  }

  function download(url, name) {
    const link = document.createElement("a");
    link.href = url;
    link.download = name;
    link.click();
  }

  function showPreview(dataUrl) {
    let overlay = document.getElementById("hanbi-screenshot-preview");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "hanbi-screenshot-preview";
      overlay.innerHTML = '<img alt="스크린샷 미리보기"><div><button type="button" data-save>저장</button><button type="button" data-close>닫기</button></div>';
      overlay.querySelector("[data-close]").addEventListener("click", () => overlay.remove());
      document.body.appendChild(overlay);
    }

    const image = overlay.querySelector("img");
    image.src = dataUrl;
    overlay.dataset.fileName = fileName("png");
    overlay.querySelector("[data-save]").onclick = () => {
      download(image.src, overlay.dataset.fileName);
      overlay.remove();
    };
  }

  function screenshot() {
    const source = video();
    if (!source?.videoWidth) return;
    const canvas = document.createElement("canvas");
    canvas.width = source.videoWidth;
    canvas.height = source.videoHeight;
    canvas.getContext("2d")?.drawImage(source, 0, 0);
    showPreview(canvas.toDataURL("image/png"));
  }

  async function togglePip() {
    const source = video();
    if (!source?.requestPictureInPicture) return;
    if (document.pictureInPictureElement) await document.exitPictureInPicture();
    else await source.requestPictureInPicture();
  }

  function toggleRecording(buttonElement) {
    if (recording) {
      recording.stop();
      return;
    }

    const source = video();
    const stream = source?.captureStream?.() ?? source?.mozCaptureStream?.();
    if (!stream || typeof MediaRecorder === "undefined") return;
    const chunks = [];
    recording = new MediaRecorder(stream);
    recording.addEventListener("dataavailable", (event) => event.data.size && chunks.push(event.data));
    recording.addEventListener("stop", () => {
      const blob = new Blob(chunks, { type: recording.mimeType || "video/webm" });
      const url = URL.createObjectURL(blob);
      download(url, fileName("webm"));
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      recording = null;
      buttonElement.textContent = "REC";
      buttonElement.classList.remove("is-recording");
    });
    recording.start(1000);
    buttonElement.textContent = "STOP";
    buttonElement.classList.add("is-recording");
  }

  function ensureTools() {
    const target = document.querySelector(".pzp-pc__bottom-buttons-right");
    const existing = document.getElementById("hanbi-player-tools");
    if (!target || (!features.screenshot && !features.recorder)) {
      existing?.remove();
      return;
    }
    if (existing?.isConnected) return;

    const root = document.createElement("span");
    root.id = "hanbi-player-tools";
    if (features.recorder) {
      const recordButton = button("녹화 시작/중지", "REC", () => toggleRecording(recordButton));
      root.appendChild(recordButton);
    }
    if (features.screenshot) root.appendChild(button("스크린샷", "SHOT", screenshot));
    if (video()?.requestPictureInPicture) root.appendChild(button("Picture in Picture", "PIP", togglePip));
    target.prepend(root);
  }

  function prepareVideo() {
    const source = video();
    if (!source || preparedVideos.has(source)) return;
    preparedVideos.add(source);
    if (features.autoUnmute && isLive()) {
      source.muted = false;
      source.addEventListener("loadeddata", () => { source.muted = false; }, { once: true });
    }
  }

  function removeAdPopup() {
    if (!features.hideAdPopup) return;
    for (const popup of document.querySelectorAll("div[class^='popup_container'], [role='dialog']")) {
      if (/광고\s*차단\s*프로그램.*사용\s*중/i.test(popup.textContent || "")) popup.remove();
    }
  }

  function rememberAndRestoreBlindMessages() {
    if (!features.blindRestore) return;
    const items = document.querySelectorAll("[class*='live_chatting_list'] [class*='list_item'], [class*='chatting_list'] [class*='list_item']");
    for (const item of items) {
      const text = item.querySelector("[class*='message_text'], [class*='message']") ?? item;
      const current = text.textContent?.trim() || "";
      if (!/블라인드 처리/.test(current) && current) originalMessages.set(item, current);
      const original = originalMessages.get(item);
      if (original && /블라인드 처리/.test(current)) {
        text.textContent = `[블라인드 복구] ${original}`;
        text.classList.add("hanbi-restored-message");
      }
    }
  }

  async function updateTrends() {
    if (!features.trends) return;
    let bar = document.getElementById("hanbi-trends");
    const header = document.querySelector("header, [class^='header_container']");
    if (!header) return;
    if (!bar) {
      bar = document.createElement("nav");
      bar.id = "hanbi-trends";
      bar.ariaLabel = "실시간 인기 방송";
      header.after(bar);
    }
    try {
      const response = await fetch("https://api.chzzk.naver.com/service/v1/lives?size=10&sortType=POPULAR", { credentials: "include" });
      if (!response.ok) return;
      const lives = (await response.json())?.content?.data || [];
      bar.replaceChildren(...lives.slice(0, 10).map((live) => {
        const link = document.createElement("a");
        const id = live.channel?.channelId || live.channelId;
        link.href = `/live/${id}`;
        link.textContent = `${live.channel?.channelName || "스트리머"} · ${Number(live.concurrentUserCount || 0).toLocaleString()}`;
        return link;
      }));
    } catch (_) {}
  }

  function applyFeatures() {
    ensureTools();
    prepareVideo();
    removeAdPopup();
    rememberAndRestoreBlindMessages();
    if (!features.trends) document.getElementById("hanbi-trends")?.remove();
  }

  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      applyFeatures();
    });
  }

  api.storage.local.get("features").then(({ features: saved }) => {
    features = { ...defaults, ...saved };
    applyFeatures();
    updateTrends();
    trendTimer = setInterval(updateTrends, 60_000);
  });

  api.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.features) return;
    features = { ...defaults, ...changes.features.newValue };
    applyFeatures();
    updateTrends();
  });

  new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener("pagehide", () => clearInterval(trendTimer), { once: true });
})();
